#pragma once

void debug_setup();
void debug_handle();
void printd(const char *format, ...);